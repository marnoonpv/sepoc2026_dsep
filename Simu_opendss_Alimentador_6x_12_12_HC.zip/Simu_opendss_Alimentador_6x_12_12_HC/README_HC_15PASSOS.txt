# Rotina HC (15 passos) — Circuito Original

## O que tem aqui
- `Master_base_only_HC.dss`  
  Versão do master **sem** `mmgd.dss` e **sem** Solve/Exports (o driver cuida disso).

- `hc_steps/`  
  15 arquivos `mmgd_step_XX_YYYpct.dss` com `kva` e `Pmpp` escalados:
  - Step 00 = +0%
  - Step 14 = +140%
  (passo de 10%)

- `monitors_HC.dss`  
  Monitores para:
  - Trafo SE (`se_PQ`, `se_VI`)
  - Loads `c11..c62` (VI e PQ) **descomentados**
  - PVs `GD_11..GD_62` (VI e PQ)

- `RODA_HC_15PASSOS.dss`  
  Driver que executa os 15 passos e salva CSV em:
  `saidas_hc/step_XX_YYYpct/`

- `analisa_hc.py`  
  Script Python que varre `saidas_hc/`, calcula violações de tensão por alimentador e gera:
  - `relatorio_hc_por_alimentador.csv`
  - `resumo_primeira_violacao_por_alimentador.csv`

## Como rodar (OpenDSS)
1. Coloque esta pasta toda no seu diretório do caso.
2. No OpenDSS GUI:  
   `Redirect "RODA_HC_15PASSOS.dss"`

Ele vai preencher as subpastas `saidas_hc/step_*` com CSVs (monitores + profile + taps + meters).

## Como analisar (Python)
No mesmo diretório:
```bash
python analisa_hc.py
```

## Quando você mudar a carga (Ano A1, A2...)
- Você **troca o arquivo de carga** no master original (ex.: `Redirect loads_2026_Ano_01.dss`) e
  salva uma nova versão (por exemplo `Master_A1.dss`).
- Depois você repete o processo:
  - gere um `Master_base_only_HC_A1.dss` (sem mmgd e sem solve/exports)
  - rode `RODA_HC_15PASSOS.dss`
  - rode `analisa_hc.py`

Se você me entregar o `loads_2026_Ano_01.dss` (ou o Master A1 completo), eu já deixo o pacote A1 pronto também.
